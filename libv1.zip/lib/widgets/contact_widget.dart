import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:send_nkap/controllers/transaction_controller.dart';
import 'package:send_nkap/gen/assets.gen.dart';
import 'package:send_nkap/ressources/app_colors.dart';
import 'package:send_nkap/ressources/app_styles.dart';
import 'package:send_nkap/ressources/constants.dart';

class ContactWidget extends StatelessWidget {
  final Contact contact;
  ContactWidget({super.key, required this.contact});

  final TransactionController _transactionController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10.0),
      margin: const EdgeInsets.only(bottom: 10.0),
      decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(Constants.defaultBorderRadius)),
      child: Row(
        children: [
          Container(
            width: 45.0,
            height: 45.0,
            decoration: const BoxDecoration(
                color: AppColors.primary, shape: BoxShape.circle),
            child: Center(
              child: Text(
                contact.displayName != null
                    ? contact.displayName![0]
                    : contact.familyName != null
                        ? contact.familyName![0]
                        : contact.givenName != null
                            ? contact.givenName![0]
                            : contact.middleName != null
                                ? contact.middleName![0]
                                : contact.androidAccountName != null
                                    ? contact.androidAccountName![0]
                                    : "U",
                style: AppStyles.textStyle(
                  color: AppColors.white,
                  size: 18.0,
                ),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: Text(
                  contact.displayName != null &&
                          _transactionController.isName(contact.displayName!)
                      ? contact.displayName!
                      : contact.familyName != null &&
                              _transactionController.isName(contact.familyName!)
                          ? contact.familyName!
                          : contact.givenName != null &&
                                  _transactionController
                                      .isName(contact.givenName!)
                              ? contact.givenName!
                              : contact.middleName != null &&
                                      _transactionController
                                          .isName(contact.middleName!)
                                  ? contact.middleName!
                                  : "Unknow",
                  style: AppStyles.textStyle(color: AppColors.dark),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: Text(
                  contact.phones != null && contact.phones!.isNotEmpty
                      ? contact.phones![0].value!
                      : "",
                  style: AppStyles.textStyle(color: AppColors.dark),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
