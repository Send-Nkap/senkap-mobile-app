import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:send_nkap/ressources/app_styles.dart';

class Commons {
  static void snackBar(
      {required Color bgColor,
      required Color textColor,
      bool hasSpecialCharacters = false,
      required String description}) {
    Get.rawSnackbar(
        backgroundColor: bgColor,
        borderRadius: 10.0,
        // colorText: AppColors.white,
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.only(bottom: 40.0, left: 22.0, right: 22.0),
        messageText: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4.0),
          child: Center(
            child: Text(
              description,
              textAlign: TextAlign.center,
              style: AppStyles.textStyle(
                color: textColor,
                size: 12,
              ),
            ),
          ),
        ),
        padding: const EdgeInsets.symmetric(vertical: 10.0));
  }
}
