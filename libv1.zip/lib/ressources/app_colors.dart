import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF3DD6D0);
  // static const Color primary = Color(0xFF706FE5);
  // static const Color primary300 = Color(0xFFC8D6FF);
  static const Color primary300 = Color(0xff64DED9);
  static const Color bgColor = Color(0xFFf2f4f5);
  // static const Color primaryClick = Color(0xff31ABA6);

  static const Color dark = Color(0xFF000000);
  // static const Color dark = Color(0xFF101D50);
  static const Color white = Color(0xFFFFFFFF);
  static const Color grey = Color(0xFF848484);

  // Success or error colors
  static const Color errorMain = Color(0xffFF4842);
  static const Color errorHover = Color(0xffFF6D68);
  static const Color errorClick = Color(0xffCC3A35);
  static const Color success = Color(0xFF4BB543);

  // Fields colors
  static const Color chatFieldHint = Color(0xFF83898E);
  static const Color imputBg = Color(0xFFE1E3E7);

  // Top nav color
  static const Color iconInactiv = Color(0xFF616161);

  static const Color historyComponentBg = Color(0x99FAF4E6);
}
