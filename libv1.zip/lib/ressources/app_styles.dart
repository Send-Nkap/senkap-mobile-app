import 'package:flutter/material.dart';
import 'package:send_nkap/gen/fonts.gen.dart';

class AppStyles {
  static TextStyle textStyle(
          {required Color color,
          FontWeight weight = FontWeight.w400,
          double size = 15.0,
          double? height}) =>
      TextStyle(
        color: color,
        fontFamily: FontFamily.monaSans,
        fontWeight: weight,
        // height: 0.8,
        fontSize: size,
        height: height,
      );
}
