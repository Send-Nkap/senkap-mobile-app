import 'dart:math';

import 'package:contacts_service/contacts_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:send_nkap/controllers/transaction_controller.dart';
import 'package:send_nkap/gen/assets.gen.dart';
import 'package:send_nkap/ressources/app_colors.dart';
import 'package:send_nkap/ressources/app_styles.dart';
import 'package:send_nkap/ressources/constants.dart';
import 'package:send_nkap/ressources/data.dart';
import 'package:send_nkap/widgets/contact_widget.dart';

class TransferPage extends StatelessWidget {
  TransferPage({super.key});
  List<Map<String, dynamic>> recentList = [
    {"shortName": "MT", "color": colorList[0], "name": "Mael Toukap"},
    {"shortName": "J", "color": colorList[1], "name": "Jean"},
    {"shortName": "N", "color": colorList[2], "name": "Ngamba"},
    {"shortName": "B", "color": colorList[3], "name": "Booming"},
    {"shortName": "JP", "color": colorList[4], "name": "Jean Paul"},
    {"shortName": "JM", "color": colorList[5], "name": "Jean Mark"},
    {"shortName": "V", "color": colorList[6], "name": "Victor"},
  ];

  final TransactionController _transactionController =
      Get.put(TransactionController());
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recents',
              style: AppStyles.textStyle(
                color: AppColors.grey,
                size: 16,
                weight: FontWeight.w600,
                // height: 0.14,
                // letterSpacing: -0.08,
              ),
            ),
            SizedBox(
              height: 115.0,
              child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemCount: 5,
                  padding: EdgeInsets.zero,
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Container(
                          width: 45.0,
                          height: 45.0,
                          margin: EdgeInsets.only(
                              top: Constants.defaultHorizontalMargin,
                              left: index != 0 ? 10.0 : 0.0),
                          // padding: EdgeInsets.all(10.0),
                          decoration: BoxDecoration(
                              color: recentList[index]['color'],
                              shape: BoxShape.circle),
                          child: Center(
                            child: Text(
                              recentList[index]['shortName'],
                              style: AppStyles.textStyle(
                                color: AppColors.white,
                                size: 18.0,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.only(top: 5.0),
                          width: 45.0,
                          child: Text(
                            recentList[index]['name'].split(' ')[0],
                            textAlign: TextAlign.center,
                          ),
                        )
                      ],
                    );
                  }),
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.all(10.0),
          margin: EdgeInsets.only(
            top: Constants.defaultHorizontalMargin,
            bottom: 8.0,
          ),
          decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius:
                  BorderRadius.circular(Constants.defaultBorderRadius)),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10.0),
                decoration: const BoxDecoration(
                    color: AppColors.primary, shape: BoxShape.circle),
                child: Image.asset(
                  Assets.icons.giftPng.path,
                  // color: AppColors.white,
                  width: 30.0,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Invite a friend",
                      style: AppStyles.textStyle(color: AppColors.dark),
                    ),
                    Text(
                      "Get up to 10% by inviting a friend",
                      style: AppStyles.textStyle(
                        color: AppColors.dark,
                        size: 13.0,
                      ),
                    )
                  ],
                ),
              )
            ],
          ),
        ),

        Obx(() {
          return !_transactionController.isContactAcessGranted.value
              ? GestureDetector(
                  onTap: () async {
                    _transactionController.getContacts();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(10.0),
                    // margin:
                    //     EdgeInsets.symmetric(vertical: Constants.defaultHorizontalMargin),
                    decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: BorderRadius.circular(
                            Constants.defaultBorderRadius)),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10.0),
                          decoration: const BoxDecoration(
                              color: AppColors.primary, shape: BoxShape.circle),
                          child: SvgPicture.asset(
                            Assets.icons.adressBook,
                            color: AppColors.white,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Access your contacts",
                                style:
                                    AppStyles.textStyle(color: AppColors.dark),
                              ),
                              Text(
                                "Share money with your contacts",
                                style: AppStyles.textStyle(
                                  color: AppColors.dark,
                                  size: 13.0,
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                )
              : const SizedBox();
        }),
        Obx(() {
          return _transactionController.contacts.isNotEmpty
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 30.0, bottom: 20.0),
                      child: Text(
                        'Conatcts on Send Nkap',
                        style: AppStyles.textStyle(
                          color: AppColors.grey,
                          size: 16,
                          weight: FontWeight.w600,
                          // height: 0.14,
                          // letterSpacing: -0.08,
                        ),
                      ),
                    ),
                    ListView.builder(
                        scrollDirection: Axis.vertical,
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: 10,
                        padding: EdgeInsets.zero,
                        itemBuilder: (context, index) {
                          return ContactWidget(
                            contact: _transactionController.contacts[index],
                          );
                        })
                  ],
                )
              : const SizedBox();
        })

        // Container(
        //   margin: EdgeInsets.only(top: Constants.defaultHorizontalMargin),
        //   padding: EdgeInsets.all(10.0),
        //   decoration: BoxDecoration(
        //       color: AppColors.errorHover, shape: BoxShape.circle),
        //   child: Text(
        //     "MT",
        //     style: AppStyles.textStyle(
        //       color: AppColors.white,
        //       size: 18.0,
        //     ),
        //   ),
        // ),
      ],
    );
  }
}
