import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:badges/badges.dart' as badges;
import 'package:send_nkap/controllers/tab_bar_controller.dart';
import 'package:send_nkap/controllers/bottom_nav_bar_controller.dart';
import 'package:send_nkap/controllers/transaction_controller.dart';
import 'package:send_nkap/gen/assets.gen.dart';
import 'package:send_nkap/ressources/app_colors.dart';
import 'package:send_nkap/ressources/app_styles.dart';
import 'package:send_nkap/ressources/constants.dart';
import 'package:send_nkap/screens/main/pages/history_page.dart';
import 'package:send_nkap/widgets/history_item_widget.dart';
import 'package:send_nkap/widgets/icon_button_widget.dart';
import 'package:send_nkap/widgets/primary_button_widget.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  // final BottomNavBarController _bottomNavBarController = Get.find();

  final TabBarController _tabController = Get.put(TabBarController());
  final TransactionController _transactionController =
      Get.put(TransactionController());
  final List<String> tabListItem = [
    "Balance",
    "Rewards",
    "Shared",
    // "Transferts",
  ];

  final List<Map<String, dynamic>> mainActionsList = [
    {"title": "Recharge", "icon": Assets.icons.recharge},
    {"title": "Withdraw", "icon": Assets.icons.remove},
  ];

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {},
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row(
          //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //   children: [
          //     Container(
          //       padding: const EdgeInsets.all(8.0),
          //       decoration: BoxDecoration(
          //           color: AppColors.iconInactiv.withOpacity(0.5),
          //           shape: BoxShape.circle),
          //       child: const Icon(
          //         FontAwesomeIcons.user,
          //         color: AppColors.white,
          //         size: 18.0,
          //       ),
          //     ),
          //     Row(
          //       children: [
          //         Text(
          //           'Home',
          //           style: AppStyles.textStyle(
          //             color: AppColors.dark,
          //             size: 18,
          //             weight: FontWeight.w700,
          //           ),
          //         ),
          //         const SizedBox(width: 35.0),
          //         const Icon(
          //           FontAwesomeIcons.chartSimple,
          //           color: AppColors.dark,
          //           size: 18.0,
          //         ),
          //         const SizedBox(width: 35.0),
          //         SvgPicture.asset(
          //           Assets.icons.service,
          //           width: 23.0,
          //           height: 23.0, //20.0
          //           color: AppColors.dark,
          //         ),
          //         const SizedBox(width: 35.0),
          //         SvgPicture.asset(
          //           Assets.icons.bell,
          //           width: 23.0,
          //           height: 23.0, //20.0
          //           color: AppColors.dark,
          //         ),
          //       ],
          //     ),
          //   ],
          // ),
          // Padding(
          //   padding: const EdgeInsets.only(top: 25.0, bottom: 20.0),
          //   child: SizedBox(
          //     height: 33.0,
          //     child: ListView.builder(
          //         shrinkWrap: true,
          //         itemCount: tabListItem.length,
          //         scrollDirection: Axis.horizontal,
          //         physics: const NeverScrollableScrollPhysics(),
          //         itemBuilder: ((context, index) {
          //           return GestureDetector(
          //             onTap: () {
          //               _tabController.selectedSoldTabIndex(index);
          //             },
          //             child: Obx(() {
          //               return Container(
          //                 margin:
          //                     EdgeInsets.only(left: index != 0 ? 10.0 : 0.0),
          //                 padding: const EdgeInsets.symmetric(
          //                     vertical: 8.0, horizontal: 12.0),
          //                 decoration: BoxDecoration(
          //                   color: _tabController.selectedSoldTabIndex.value ==
          //                           index
          //                       ? AppColors.white
          //                       : AppColors.bgColor,
          //                   borderRadius: BorderRadius.circular(
          //                       Constants.defaultBorderRadius),
          //                 ),
          //                 child: Text(
          //                   tabListItem[index],
          //                   style: AppStyles.textStyle(
          //                     color: index ==
          //                             _tabController.selectedSoldTabIndex.value
          //                         ? AppColors.dark
          //                         : AppColors.iconInactiv,
          //                     size: 15.0,
          //                   ),
          //                 ),
          //               );
          //             }),
          //           );
          //         })),
          //   ),
          // ),
          // Container(
          //   // width: Constants.screenWidth(context) / 2.7,
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       Container(
          //         padding:
          //             EdgeInsets.symmetric(vertical: 8.0, horizontal: 10.0),
          //         decoration: BoxDecoration(
          //           color: AppColors.white,
          //           borderRadius: BorderRadius.circular(10.0),
          //         ),
          //         child: Text(
          //           "Balances",
          //           style: AppStyles.textStyle(
          //             color: AppColors.dark,
          //             size: 13.0,
          //           ),
          //         ),
          //       ),
          //       Text(
          //         "Rewards",
          //         style: AppStyles.textStyle(
          //           color: AppColors.dark,
          //           size: 13.0,
          //         ),
          //       ),
          //       Text(
          //         "Shared",
          //         style: AppStyles.textStyle(
          //           color: AppColors.dark,
          //           size: 13.0,
          //         ),
          //       )
          //     ],
          //   ),
          // )
          Container(
            padding: EdgeInsets.all(Constants.defaultHorizontalMargin),
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius:
                  BorderRadius.circular(Constants.defaultBorderRadius),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "2000 " "XAF",
                      style: AppStyles.textStyle(
                        color: AppColors.dark,
                        size: 18,
                        weight: FontWeight.w600,
                      ),
                    ),
                    Image.asset(Assets.icons.cmrFlag.path)
                  ],
                ),
                Text(
                  "Francs CFA",
                  style: AppStyles.textStyle(
                    color: AppColors.dark,
                    size: 13,
                    height: 0.9,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 17.0),
                  child: SizedBox(
                    height: 33.0,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: mainActionsList.length,
                      scrollDirection: Axis.horizontal,
                      itemBuilder: ((context, index) {
                        return IconButtonWidget(
                          hasMarginLeft: index != 0,
                          icon: mainActionsList[index]["icon"],
                          text: mainActionsList[index]["title"],
                          onTap: () {},
                        );
                        //  GestureDetector(
                        //   onTap: () {},
                        //   child: Container(
                        //     margin:
                        //         EdgeInsets.only(left: index != 0 ? 10.0 : 0.0),
                        //     padding: const EdgeInsets.symmetric(
                        //         vertical: 8.0, horizontal: 12.0),
                        //     decoration: BoxDecoration(
                        //       color: AppColors.primary.withOpacity(0.5),
                        //       borderRadius: BorderRadius.circular(
                        //           Constants.defaultBorderRadius),
                        //     ),
                        //     child: Row(
                        //       children: [
                        //         SvgPicture.asset(
                        //           mainActionsList[index]["icon"],
                        //           color: AppColors.dark,
                        //         ),
                        //         // Container(
                        //         //   padding: EdgeInsets.all(10.0),
                        //         //   decoration: BoxDecoration(
                        //         //       color: AppColors.white,
                        //         //       shape: BoxShape.circle),
                        //         //   child: SvgPicture.asset(
                        //         //     mainActionsList[index]["icon"],
                        //         //     color: AppColors.dark,
                        //         //   ),
                        //         // ),
                        //         Padding(
                        //           padding: const EdgeInsets.only(left: 10.0),
                        //           child: Text(
                        //             mainActionsList[index]["title"],
                        //             style: AppStyles.textStyle(
                        //               color: AppColors.dark,
                        //               size: 15.0,
                        //             ),
                        //           ),
                        //         ),
                        //       ],
                        //     ),
                        //   ),
                        // );
                      }),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20.0, bottom: 16.0),
                  child: Text(
                    "Last transaction",
                    style: AppStyles.textStyle(
                      color: AppColors.iconInactiv,
                      size: 15.0,
                    ),
                  ),
                ),
                Obx(() {
                  return HistoryItemComponent(
                    onTap: () {
                      _transactionController.isLastTransactionDetailsActivated(
                          !_transactionController
                              .isLastTransactionDetailsActivated.value);
                    },
                    isTransactionDetailsActivated: _transactionController
                        .isLastTransactionDetailsActivated.value,
                  );
                })
              ],
            ),
          ),
          HistoryPage(isSeeMoreVisibles: true),
        ],
      ),
    );
  }
}
