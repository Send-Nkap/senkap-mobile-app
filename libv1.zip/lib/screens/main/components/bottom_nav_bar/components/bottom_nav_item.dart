import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:send_nkap/ressources/app_colors.dart';
import 'package:send_nkap/ressources/app_styles.dart';

class BottomNavItem extends StatelessWidget {
  final String title;
  final String icon;
  final bool isActive;
  const BottomNavItem(
      {super.key,
      required this.title,
      required this.icon,
      required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(18.0),
      child: SvgPicture.asset(
        icon,
        width: title == "Cartes" || title == "Accueil" ? 27.0 : 23.0,
        height: 25.0, //20.0
        color: isActive ? AppColors.primary : AppColors.iconInactiv,
      ),
    );
  }
}
