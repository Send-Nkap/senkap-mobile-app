import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:send_nkap/controllers/bottom_nav_bar_controller.dart';
import 'package:send_nkap/gen/assets.gen.dart';
import 'package:send_nkap/ressources/app_colors.dart';
import 'package:send_nkap/screens/main/components/bottom_nav_bar/components/bottom_nav_item.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BottomNavBar extends StatelessWidget {
  BottomNavBar({super.key});
  final BottomNavBarController _bottomNavBarController =
      Get.put(BottomNavBarController());

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 30.0),
        child: Obx(() {
          return Material(
            elevation: _bottomNavBarController.isBottomNavBarTransparent.value
                ? 0.0
                : 10.0,
            color: _bottomNavBarController.isBottomNavBarTransparent.value
                ? AppColors.white.withOpacity(0.5)
                : null,
            borderRadius: BorderRadius.circular(30.0),
            child: IntrinsicWidth(
              child: Container(
                // margin: const EdgeInsets.only(bottom: 55.0),
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                decoration: BoxDecoration(
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(30.0)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      onTap: () async {
                        _bottomNavBarController.setPageIndex(0);
                      },
                      child: Obx(() {
                        return BottomNavItem(
                          title: "Accueil",
                          icon: Assets.icons.home,
                          isActive:
                              _bottomNavBarController.pageIndex.value == 0,
                        );
                      }),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      onTap: () {
                        _bottomNavBarController.setPageIndex(1);
                      },
                      child: Obx(() {
                        return BottomNavItem(
                          title: "Transfert",
                          icon: Assets.icons.transfert,
                          isActive:
                              _bottomNavBarController.pageIndex.value == 1,
                        );
                      }),
                    ),
                    InkWell(
                      splashColor: Colors.transparent,
                      focusColor: Colors.transparent,
                      highlightColor: Colors.transparent,
                      hoverColor: Colors.transparent,
                      onTap: () async {
                        _bottomNavBarController.setPageIndex(2);
                      },
                      child: Obx(() {
                        return BottomNavItem(
                          title: "Historique",
                          icon: Assets.icons.history,
                          isActive:
                              _bottomNavBarController.pageIndex.value == 2,
                        );
                      }),
                    ),
                    // InkWell(
                    //   splashColor: Colors.transparent,
                    //   focusColor: Colors.transparent,
                    //   highlightColor: Colors.transparent,
                    //   hoverColor: Colors.transparent,
                    //   onTap: () {
                    //     _bottomNavBarController.setPageIndex(4);
                    //   },
                    //   child: Obx(() {
                    //     return BottomNavItem(
                    //       title: "Support",
                    //       icon: Assets.icons.service,
                    //       isActive: _bottomNavBarController.pageIndex.value == 4,
                    //     );
                    //   }),
                    // ),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
