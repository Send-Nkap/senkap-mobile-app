import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:send_nkap/controllers/bottom_nav_bar_controller.dart';
import 'package:send_nkap/controllers/tab_bar_controller.dart';
import 'package:send_nkap/gen/assets.gen.dart';
import 'package:send_nkap/ressources/app_colors.dart';
import 'package:send_nkap/ressources/app_styles.dart';
import 'package:send_nkap/ressources/constants.dart';
import 'package:send_nkap/widgets/input_field_widget.dart';

class AppBarComponent extends StatelessWidget {
  AppBarComponent({super.key});
  final TabBarController _tabController = Get.put(TabBarController());
  final BottomNavBarController _bottomNavBarController = Get.find();
  final List<String> tabAccountListItem = [
    "Balance",
    "Rewards",
    "Shared",
    // "Transferts",
  ];
  final List<String> tabHistoryListItem = [
    "All",
    "Recharges",
    "Withdraw",
    "Transferts",
  ];

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Obx(() {
        return Material(
          elevation:
              _bottomNavBarController.isAppBarElevated.value ? 10.0 : 0.0,
          child: Container(
            color: AppColors.bgColor,
            padding: EdgeInsets.only(
              left: Constants.defaultHorizontalMargin,
              right: Constants.defaultHorizontalMargin,
              top: Constants.defaultHorizontalMargin,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    if (_bottomNavBarController.pageIndex.value == 0)
                      Container(
                        padding: const EdgeInsets.all(8.0),
                        decoration: BoxDecoration(
                            color: AppColors.iconInactiv.withOpacity(0.5),
                            shape: BoxShape.circle),
                        child: const Icon(
                          FontAwesomeIcons.user,
                          color: AppColors.white,
                          size: 18.0,
                        ),
                      ),
                    if (_bottomNavBarController.pageIndex.value != 0)
                      Padding(
                        padding: EdgeInsets.only(
                            bottom: _bottomNavBarController.pageIndex.value != 0
                                ? 0.0
                                : 0.0),
                        child: Text(
                          _bottomNavBarController.pageIndex.value == 1
                              ? 'Transfer'
                              : 'Transactions',
                          style: AppStyles.textStyle(
                            color: AppColors.dark,
                            size: 18,
                            weight: FontWeight.w700,
                          ),
                        ),
                      ),
                    if (_bottomNavBarController.pageIndex.value == 0)
                      Row(
                        children: [
                          Text(
                            'Home',
                            style: AppStyles.textStyle(
                              color: AppColors.dark,
                              size: 18,
                              weight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(width: 35.0),
                          const Icon(
                            FontAwesomeIcons.chartSimple,
                            color: AppColors.dark,
                            size: 18.0,
                          ),
                          const SizedBox(width: 35.0),
                          SvgPicture.asset(
                            Assets.icons.service,
                            width: 23.0,
                            height: 23.0, //20.0
                            color: AppColors.dark,
                          ),
                          const SizedBox(width: 35.0),
                          SvgPicture.asset(
                            Assets.icons.bell,
                            width: 23.0,
                            height: 23.0, //20.0
                            color: AppColors.dark,
                          ),
                        ],
                      ),
                    if (_bottomNavBarController.pageIndex.value == 1)
                      SvgPicture.asset(
                        Assets.icons.scan,
                        // width: 23.0,
                        // height: 23.0, //20.0
                        color: AppColors.dark,
                      )
                  ],
                ),
                if (_bottomNavBarController.pageIndex.value != 1)
                  Padding(
                    padding: const EdgeInsets.only(top: 25.0, bottom: 20.0),
                    child: SizedBox(
                      height: 33.0,
                      child: _bottomNavBarController.pageIndex.value == 0
                          ? ListView.builder(
                              shrinkWrap: true,
                              itemCount: tabAccountListItem.length,
                              scrollDirection: Axis.horizontal,
                              physics: const NeverScrollableScrollPhysics(),
                              itemBuilder: ((context, index) {
                                return GestureDetector(
                                  onTap: () {
                                    _tabController.selectedSoldTabIndex(index);
                                  },
                                  child: Obx(() {
                                    return Container(
                                      margin: EdgeInsets.only(
                                          left: index != 0 ? 10.0 : 0.0),
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0, horizontal: 12.0),
                                      decoration: BoxDecoration(
                                        color: _tabController
                                                    .selectedSoldTabIndex
                                                    .value ==
                                                index
                                            ? AppColors.white
                                            : AppColors.bgColor,
                                        borderRadius: BorderRadius.circular(
                                            Constants.defaultBorderRadius),
                                      ),
                                      child: Text(
                                        tabAccountListItem[index],
                                        style: AppStyles.textStyle(
                                          color: index ==
                                                  _tabController
                                                      .selectedSoldTabIndex
                                                      .value
                                              ? AppColors.dark
                                              : AppColors.iconInactiv,
                                          size: 15.0,
                                        ),
                                      ),
                                    );
                                  }),
                                );
                              }))
                          : ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              padding: EdgeInsets.zero,
                              itemCount: tabHistoryListItem.length,
                              itemBuilder: ((context, index) {
                                return GestureDetector(
                                  onTap: () {
                                    _bottomNavBarController
                                        .selectedHistoryFilter(index);
                                  },
                                  child: Obx(() {
                                    return Container(
                                      margin: EdgeInsets.only(
                                          left: index != 0 ? 10.0 : 0.0),
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0, horizontal: 12.0),
                                      decoration: BoxDecoration(
                                        color: _bottomNavBarController
                                                    .selectedHistoryFilter
                                                    .value ==
                                                index
                                            ? AppColors.white
                                            : AppColors.bgColor,
                                        borderRadius: BorderRadius.circular(
                                            Constants.defaultBorderRadius),
                                      ),
                                      child: Text(
                                        tabHistoryListItem[index],
                                        style: AppStyles.textStyle(
                                          color: index ==
                                                  _bottomNavBarController
                                                      .selectedHistoryFilter
                                                      .value
                                              ? AppColors.dark
                                              : AppColors.iconInactiv,
                                          size: 15.0,
                                        ),
                                      ),
                                    );
                                  }),
                                );
                              }),
                            ),
                    ),
                  ),
                if (_bottomNavBarController.pageIndex.value == 1)
                  Padding(
                    padding: const EdgeInsets.only(top: 25.0, bottom: 20.0),
                    child: InputField(
                      labelText: "Name, username, phone",
                      hasIcon: false,
                      isElevated: false,
                      hasShadow: false,
                      hasSuffix: true,
                      hasMarginRight: false,
                      contentPadding: 14.0,
                      suffixIcon: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10.0),
                        child: SvgPicture.asset(
                          Assets.icons.userSearch,
                          width: 23.0,
                          height: 23.0, //20.0
                          color: AppColors.iconInactiv,
                        ),
                      ),
                      icon: Icons.abc,
                      keyboardType: TextInputType.number,
                      iconColor: AppColors.dark,
                      value: "",
                      onChanged: (String value) {},
                    ),
                  ),
              ],
            ),
          ),
        );
      }),
    );
  }
}
