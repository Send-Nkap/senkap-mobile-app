import 'package:contacts_service/contacts_service.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';

class TransactionController extends GetxController {
  RxBool isLastTransactionDetailsActivated = false.obs;
  RxInt selectedTransaction = (-1).obs;

  RxBool isContactAcessGranted = false.obs;
  List<Contact> contacts = (List<Contact>.of([])).obs;

  void getContacts() async {
    contacts.clear();
    if (await Permission.contacts.request().isGranted) {
      // Either the permission was already granted before or the user just granted it.
      // Get all contacts without thumbnail (faster)
      isContactAcessGranted(true);
      List<Contact> newContacts =
          (await ContactsService.getContacts(withThumbnails: false));
      for (var contact in newContacts) {
        if (contact.phones != null && contact.phones!.isNotEmpty) {
          if (!contacts.contains(contact)) {
            // contact.phones![0].value =
            //     formatPhoneNumber(contact.phones![0].value!);
            contacts.add(contact);
            print(contact.toMap());
          }
        }
      }
      newContacts.toSet();
      // TODO: check if each contact is already on Send Nkap
    }
  }

  bool isName(String input) {
    // Ajoutez ici votre logique de validation pour un nom
    // // Par exemple, vous pourriez vérifier s'il contient des espaces ou est composé de caractères alphabétiques.
    return !input.contains("+237");
    // return !input.contains(
    //     RegExp(r'[0-9]')); // Vérification simple sans caractères numériques
  }

  bool isPhoneNumber(String input) {
    // Ajoutez ici votre logique de validation pour un numéro de téléphone
    // Peut-être en utilisant la longueur ou le format spécifique du numéro.
    return input.startsWith('+') &&
        input.length > 5; // Vérification simple pour un numéro international
  }

  String formatPhoneNumber(String phoneNumber) {
    // Enlever "+237" si présent
    if (phoneNumber.startsWith('+237')) {
      phoneNumber = phoneNumber.substring(4);
    }

    // Rajouter "6" s'il n'y en a pas après
    if (!phoneNumber.startsWith('6')) {
      phoneNumber = '6$phoneNumber';
    }

    // Rajouter des espaces tous les deux caractères après le "6"
    phoneNumber = phoneNumber.replaceAllMapped(
        RegExp(r".{2}"), (match) => '${match.group(0)} ');

    return phoneNumber.trim(); // Supprimer les espaces en trop aux extrémités
  }

  @override
  void onInit() async {
    if (await Permission.contacts.isGranted) {
      getContacts();
    }
    super.onInit();
  }
}
