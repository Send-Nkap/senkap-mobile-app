import 'package:get/get.dart';

class TabBarController extends GetxController {
  RxInt selectedSoldTabIndex = 0.obs;
  RxInt selectedHistoryTabIndex = 0.obs;
}