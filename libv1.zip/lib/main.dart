import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:send_nkap/ressources/app_colors.dart';
import 'package:send_nkap/screens/account_verification/account_verification_stepper_screen.dart';
import 'package:send_nkap/screens/login/login_screen.dart';
import 'package:send_nkap/screens/main/main_screen.dart';
import 'package:send_nkap/screens/onBoad/onBoad_screen.dart';
import 'package:send_nkap/screens/otp/otp_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',
      localizationsDelegates: const [
        GlobalWidgetsLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      // initialBinding: BindingsBuilder(() {
      //   Get.lazyPut(() => CameraControler());
      // }),
      supportedLocales: const [Locale('en', 'US'), Locale('fr', 'FR')],
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
        useMaterial3: true,
      ),
      // home: AccountVerificationStepperScreen(),
      home: MainScreen(),
      // home: OnBoardScreen(),
    );
  }
}
